---
Views:
- '13'
author: Jihee Jeong
date: 2018-03-16 15:34:05
id: 30989
image: /wp-content/uploads/2018/03/1.0-3.jpg
imagef: 2018-03-30989.jpg
permalink: /%ec%9b%8c%ec%8b%b1%ed%84%b4-%eb%89%b4%ec%8a%a4-%ed%88%ac%eb%8d%b0%ec%9d%b4-030118/
title: "\uC6CC\uC2F1\uD134 \uB274\uC2A4 \uD22C\uB370\uC774 030118"
youtube: EK8OW3y4HSc
youtube-url: https://www.youtube.com/watch?v=EK8OW3y4HSc
---

2018년 03월 01일 저녁뉴스 WKTV NEWS CENTER
  
WKTV WORLD NEWS 워싱턴 뉴스 투데이 030118