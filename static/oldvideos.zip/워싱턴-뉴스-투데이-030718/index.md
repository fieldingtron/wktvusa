---
Views:
- '11'
author: Jihee Jeong
date: 2018-03-16 16:20:41
id: 31001
image: /wp-content/uploads/2018/03/1.0-6-e1521235229187.jpg
imagef: 2018-03-31001.jpg
permalink: /%ec%9b%8c%ec%8b%b1%ed%84%b4-%eb%89%b4%ec%8a%a4-%ed%88%ac%eb%8d%b0%ec%9d%b4-030718/
tags:
- KOREA ONE
- KOREA TODAY
- KOREAN NEWS
- Korus News
- NEWS TODAY
- "NEWS \uB274\uC2A4\uD22C\uB370\uC774"
- SIRIUS XM CH144
- WASHINGTON KOREAN NEWS
- WASHINGTON NEWS
- WASHINGTON NEWS TODAY
- WKTV
- XM144
- "\uB274\uC2A4"
- "\uBBF8\uAD6D\uB0B4 \uD55C\uAD6D \uB274\uC2A4"
- "\uC6CC\uC2F1\uD134 \uB274\uC2A4"
- "\uC6CC\uC2F1\uD134 \uB274\uC2A4 \uD22C\uB370\uC774"
- "\uCF54\uB7EC\uC2A4"
- "\uCF54\uB7EC\uC2A4 \uB274\uC2A4"
- "\uCF54\uB9AC\uC544 \uD22C\uB370\uC774"
- "\uCF54\uB9AC\uC548 \uB274\uC2A4"
- "\uD55C\uAD6D\uB274\uC2A4"
title: "\uC6CC\uC2F1\uD134 \uB274\uC2A4 \uD22C\uB370\uC774 030718"
youtube: SbzWzHRvSrg
youtube-url: https://www.youtube.com/watch?v=SbzWzHRvSrg
---

2018년 03월 07일 저녁뉴스 WKTV NEWS CENTER
  
WKTV WORLD NEWS 워싱턴 뉴스 투데이 030718