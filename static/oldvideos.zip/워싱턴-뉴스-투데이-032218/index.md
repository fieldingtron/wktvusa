---
Views:
- '8'
author: Jihee Jeong
date: 2018-04-06 10:31:06
id: 31043
image: /wp-content/uploads/2018/04/1.0-1-e1523028661912.jpg
imagef: 2018-04-31043.jpg
permalink: /%ec%9b%8c%ec%8b%b1%ed%84%b4-%eb%89%b4%ec%8a%a4-%ed%88%ac%eb%8d%b0%ec%9d%b4-032218/
title: "\uC6CC\uC2F1\uD134 \uB274\uC2A4 \uD22C\uB370\uC774 032218"
youtube: 9U_boKRSY8Q
youtube-url: https://www.youtube.com/watch?v=9U_boKRSY8Q
---

2018년 03월 22일 저녁뉴스 WKTV NEWS CENTER
  
WKTV WORLD NEWS 워싱턴 뉴스 투데이 032218