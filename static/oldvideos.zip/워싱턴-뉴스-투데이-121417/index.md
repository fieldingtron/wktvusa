---
Views:
- '7'
author: Jihee Jeong
date: 2017-12-20 19:18:22
id: 30788
image: /wp-content/uploads/2017/12/1.0-13-e1513815492946.jpg
imagef: 2017-12-30788.jpg
permalink: /%ec%9b%8c%ec%8b%b1%ed%84%b4-%eb%89%b4%ec%8a%a4-%ed%88%ac%eb%8d%b0%ec%9d%b4-121417/
tags:
- KOREA ONE
- KOREA TODAY
- KOREAN NEWS
- Korus News
- NEWS TODAY
- "NEWS \uB274\uC2A4\uD22C\uB370\uC774"
- SIRIUS XM CH144
- WASHINGTON KOREAN NEWS
- WASHINGTON NEWS
- WASHINGTON NEWS TODAY
- WKTV
- XM144
- "\uB274\uC2A4"
- "\uBBF8\uAD6D\uB0B4 \uD55C\uAD6D \uB274\uC2A4"
- "\uC6CC\uC2F1\uD134 \uB274\uC2A4"
- "\uC6CC\uC2F1\uD134 \uB274\uC2A4 \uD22C\uB370\uC774"
- "\uCF54\uB7EC\uC2A4"
- "\uCF54\uB7EC\uC2A4 \uB274\uC2A4"
- "\uCF54\uB9AC\uC544 \uD22C\uB370\uC774"
- "\uCF54\uB9AC\uC548 \uB274\uC2A4"
- "\uD55C\uAD6D\uB274\uC2A4"
title: "\uC6CC\uC2F1\uD134 \uB274\uC2A4 \uD22C\uB370\uC774 121417"
youtube: NZ4Y_mRU1-M
youtube-url: https://www.youtube.com/watch?v=NZ4Y_mRU1-M
---

2017년 12월 14일 저녁뉴스 WKTV NEWS CENTER
  
WKTV WORLD NEWS 워싱턴 뉴스 투데이 121417