---
Views:
- '9'
author: Jihee Jeong
date: 2017-02-16 11:26:29
id: 28840
image: /wp-content/uploads/2017/02/2.0-10.jpg
imagef: 2017-02-28840.jpg
permalink: /%ec%9b%8c%ec%8b%b1%ed%84%b4-%eb%89%b4%ec%8a%a4-%ed%88%ac%eb%8d%b0%ec%9d%b4-021517/
title: "\uC6CC\uC2F1\uD134 \uB274\uC2A4 \uD22C\uB370\uC774 021517"
youtube: 0JegrRzzIoQ
youtube-url: https://www.youtube.com/watch?v=0JegrRzzIoQ
---

2017년 2월 15일 저녁뉴스 WKTV NEWS CENTER
  
WKTV WORLD NEWS 워싱턴 뉴스 투데이 021517