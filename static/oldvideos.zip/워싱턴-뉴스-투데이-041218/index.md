---
Views:
- '10'
author: Jihee Jeong
date: 2018-04-16 18:27:40
id: 31091
image: /wp-content/uploads/2018/04/1.0-13-e1523921254434.jpg
imagef: 2018-04-31091.jpg
permalink: /%ec%9b%8c%ec%8b%b1%ed%84%b4-%eb%89%b4%ec%8a%a4-%ed%88%ac%eb%8d%b0%ec%9d%b4-041218/
title: "\uC6CC\uC2F1\uD134 \uB274\uC2A4 \uD22C\uB370\uC774 041218"
youtube: i-rtIufa3Yw
youtube-url: https://www.youtube.com/watch?v=i-rtIufa3Yw
---

2018년 04월 12일 저녁뉴스 WKTV NEWS CENTER
  
WKTV WORLD NEWS 워싱턴 뉴스 투데이 041218