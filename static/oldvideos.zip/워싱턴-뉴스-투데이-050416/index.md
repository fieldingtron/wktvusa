---
Views:
- '7'
author: Jihee Jeong
date: 2016-05-05 08:52:35
id: 24864
image: /wp-content/uploads/2016/05/t.jpg
imagef: 2016-05-24864.jpg
permalink: /%ec%9b%8c%ec%8b%b1%ed%84%b4-%eb%89%b4%ec%8a%a4-%ed%88%ac%eb%8d%b0%ec%9d%b4-050416/
tags:
- KOREA ONE
- KOREA TODAY
- KOREAN NEWS
- Korus News
- NEWS TODAY
- "NEWS \uB274\uC2A4\uD22C\uB370\uC774"
- SIRIUS XM CH144
- WASHINGTON KOREAN NEWS
- WASHINGTON NEWS
- WASHINGTON NEWS TODAY
- WKTV
- XM144
- "\uB274\uC2A4"
- "\uBBF8\uAD6D\uB0B4 \uD55C\uAD6D \uB274\uC2A4"
- "\uC6CC\uC2F1\uD134 \uB274\uC2A4"
- "\uC6CC\uC2F1\uD134 \uB274\uC2A4 \uD22C\uB370\uC774"
- "\uCF54\uB7EC\uC2A4"
- "\uCF54\uB7EC\uC2A4 \uB274\uC2A4"
- "\uCF54\uB9AC\uC544 \uD22C\uB370\uC774"
- "\uCF54\uB9AC\uC548 \uB274\uC2A4"
- "\uD55C\uAD6D\uB274\uC2A4"
title: "\uC6CC\uC2F1\uD134 \uB274\uC2A4 \uD22C\uB370\uC774 050416"
youtube: m6hmrOhxcbA
youtube-url: https://www.youtube.com/watch?v=m6hmrOhxcbA
---

2016년 5월 4일 저녁뉴스 WKTV NEWS CENTER
  
WKTV WORLD NEWS 워싱턴 뉴스 투데이 050416