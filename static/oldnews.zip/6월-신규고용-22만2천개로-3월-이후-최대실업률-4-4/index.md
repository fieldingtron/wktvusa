---
Views:
- '14'
author: Jihee Jeong
date: 2017-07-11 10:27:12
id: 30492
image: /wp-content/uploads/2017/07/4.0.jpg
imagef: 2017-07-30492.jpg
permalink: /6%ec%9b%94-%ec%8b%a0%ea%b7%9c%ea%b3%a0%ec%9a%a9-22%eb%a7%8c2%ec%b2%9c%ea%b0%9c%eb%a1%9c-3%ec%9b%94-%ec%9d%b4%ed%9b%84-%ec%b5%9c%eb%8c%80%ec%8b%a4%ec%97%85%eb%a5%a0-4-4/
title: "6\uC6D4 \uC2E0\uADDC\uACE0\uC6A9 22\uB9CC2\uCC9C\uAC1C\uB85C 3\uC6D4 \uC774\
  \uD6C4 \uCD5C\uB300\u2026\uC2E4\uC5C5\uB960 4.4%"
---

노동부는 오늘 지난 6월 22만2천 개의 일자리가 새로 생겼다고 발표했습니다.

이는 지난 3월 이후 최대치를 기록한 것입니다.

실업률은 5월보다는 0.1% 포인트 오른 4.4%를 기록했지만, 여전히 지난 10년을 통틀어 가장 낮은 수준에서 머물렀습니다.

이같은 현상은 기업들이 소비자들의 구매 요구가 계속 상승하고 앞으로 경제 성장률도 오를 것으로 예상하면서 일자리를 늘릴 필요성을 느끼기 때문으로 분석됐습니다.

한편, 상반기 월간 고용 창출 평균치는 18만 개로 집계됐습니다.

** **

&nbsp;