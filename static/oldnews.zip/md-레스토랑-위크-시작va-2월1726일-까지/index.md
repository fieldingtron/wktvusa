---
Views:
- '11'
author: Jihee Jeong
date: 2017-01-20 13:35:54
id: 28503
image: /wp-content/uploads/2017/01/6.1.jpg
imagef: 2017-01-28503.jpg
permalink: /md-%eb%a0%88%ec%8a%a4%ed%86%a0%eb%9e%91-%ec%9c%84%ed%81%ac-%ec%8b%9c%ec%9e%91va-2%ec%9b%941726%ec%9d%bc-%ea%b9%8c%ec%a7%80/
title: "MD \u2018\uB808\uC2A4\uD1A0\uB791 \uC704\uD06C\u2019 \uC2DC\uC791\u2026VA\
  \ 2\uC6D417~26\uC77C \uAE4C\uC9C0"
---

평소 먹지 못하던 고급음식들을 저렴한 가격으로 먹을 수 있는 기회가 있습니다.

지역 미식가들의 마음을 설레게 하는 ‘2017 레스토랑 위크가 볼티모어를 시작으로  10개도시에서 시작됐습니다.

이 행사는  전 지역에서 1월과 7,8월에  두번씩 열리는 이벤트로 메릴랜드에서는 100여개의 레스토랑이 참여합니다.

지정 레스토랑들은 점심과 저녁 이벤트 정식메뉴들을 마련합니다.

고객들은 런치와 3가지 코스를 포함한 저녁 메뉴들을 10달러에서 40달러까지 다양한 가격으로 즐길 수 있습니다.

볼티모어는 이미 13일부터 시작됐으며 22일까지  10일간 진행됩니다.

또한 한인들이 밀집한 하워드 카운티는 23일부터 2월 6일까지 진행될 예정입니다.

한편  워싱턴 DC의 경우 1월 30일부터 2월 5일까지 열리며,  버지니아·알렉산드리아지역에서는 는2월 17일부터26일까지 고급 음식을 맛 볼수 있는 기회가 열립니다.

레스토랑 위크 행사에 참여하는 식당과 메뉴 정보는 웹사이트를 통해 알 수 있습니다.

볼티모어 카운티 (baltimorerestaurantweek.com)
  
하워드 카운티 (visithowardcounty.com/howard-county-restaurant- weeks)
  
알렉산드리아 (visitalexandriava.com/restaurants/restaurant-week)
  
워싱턴 DC (ramw.org/restaurantweek)