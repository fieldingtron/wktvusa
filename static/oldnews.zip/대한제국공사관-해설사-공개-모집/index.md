---
Views:
- '19'
author: Jihee Jeong
date: 2017-05-09 11:09:46
id: 30004
image: /wp-content/uploads/2017/05/7.0-3-e1494346182716.jpg
imagef: 2017-05-30004.jpg
permalink: /%eb%8c%80%ed%95%9c%ec%a0%9c%ea%b5%ad%ea%b3%b5%ec%82%ac%ea%b4%80-%ed%95%b4%ec%84%a4%ec%82%ac-%ea%b3%b5%ea%b0%9c-%eb%aa%a8%ec%a7%91/
title: "\uB300\uD55C\uC81C\uAD6D\uACF5\uC0AC\uAD00 \uD574\uC124\uC0AC \uACF5\uAC1C\
  \ \uBAA8\uC9D1"
---

국외소재문화재단에 따르면, 응모자격은 한국어와 영어를 능통하게 구사할 수 있어야 하며 기타 성별이나 연령 제한은 없습니다

응모 희망자는 오는 26일까지  한글 이력서와 영어 자기소개서를  주미대사관 관계 부서에 제출하면 됩니다.

참고로, 공사관 복원공사는 현재 외부 공사를 완료하고 내부 공사가 진행중에 있으며 올 여름 완공을 목표로 하고 있습니다.

기타 자세한 문의는 전화(202-579-3907)로 하거나 또는 이메일(<bsjs7788@hanmail.net>)로 하면 됩니다.